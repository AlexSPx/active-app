Active Next — Play Store phone screenshots

8 real Android screenshots, in numbered upload order.
1080 x 1920, RGB PNG, English, light theme, kilograms.
Source: master at 2cd9eb361a279e6081918163d9fe0125bf1f0d2d
Captured from a standalone release-mode build with fictional local data.
Upload only the numbered PNG files. No app UI or image content was edited.
